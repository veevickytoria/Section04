<?php 

class TraversalUniqueness 
{
	const NODE_GLOBAL = 'node global';
	const NODE_PATH = 'node path'; 
	const NODE_RECENT = 'node recent';
	const NONE = 'none';
	const RELATIONSHIP_GLOBAL = 'relationship global'; 
	const RELATIONSHIP_PATH = 'relationship path';
	const RELATIONSHIP_RECENT = 'relationship recent';
}