<?php
/**
 * HTTP-specific exception
 *
 * @package NeoRest
 */

/**
 * HTTP-specific exception
 *
 * @package NeoRest
 */
class NeoRestHttpException extends Exception
{
}
