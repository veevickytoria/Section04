<?php
/**
 * HTTP 404 exception
 *
 * @package NeoRest
 */

/**
 * HTTP 404 exception
 *
 * @package NeoRest
 */
class NotFoundException extends Exception
{
}


