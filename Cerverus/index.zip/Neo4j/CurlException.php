<?php 
class CurlException extends Exception
{
}